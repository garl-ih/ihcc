// Garl Norman
// 12/08/2021
// Carlys Catering
/*
Write a program that prompts the user for the number of guests
attending an event and then computes the total price, which is
$35 per person. Display the company motto, number of guests,
price per guest, and total price. Also display a message that
indicates true or false depending on whether the job is classified
as a large event-an event with 50 or more guests
 */

import java.text.DecimalFormat;
import java.util.Scanner;

public class CarlysEventPrice {

    static final double PRICE_PER_PERSON = 35.00;

    public static void main(String[] args) {

        Scanner inputDevice;
        inputDevice = init();
        int cGuests = input(inputDevice);
        double cTotalPrice = calc(cGuests);
        output(cGuests, cTotalPrice);
    }

    public static Scanner init(){
        Scanner inputDevice = new Scanner(System.in);
        return inputDevice;
    }
    public static int input(Scanner inputDevice){
        System.out.println("Enter the number of guests: ");
        String iGuests = inputDevice.nextLine();
        int cGuests = Integer.parseInt(iGuests);
        return cGuests;

    }

    public static double calc(int cGuests){
        double cTotalPrice = cGuests * PRICE_PER_PERSON;
        return cTotalPrice;
    }

    public static void output(int cGuests, double cTotalPrice){
        DecimalFormat dollarAmt = new DecimalFormat("$#,###.00");
        System.out.println("Guests: " + cGuests);
        System.out.println("Price Per Person: " +  PRICE_PER_PERSON);
        double oTotalPrice = SpecialCalcClass.roundDouble(cTotalPrice, 100);
        System.out.println("Total Price: " + oTotalPrice);
        if (cGuests > 50){
            System.out.println("Large Event: True");
        } else {
            System.out.println("Large Event: False");
        }
    }
}
