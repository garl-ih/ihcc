public class SpecialCalcClass {
    public static double roundDouble(double numberValue, double roundValue){
        return Math.round(numberValue * roundValue) / roundValue;
    }
}
